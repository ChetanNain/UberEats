CREATE TABLE UberEats.Dishes(
restaurantID INT,
dishName varchar(50),
mainIngredients varchar(200),
dishImage longblob,
dishPrice DECIMAL(5,2),
description VARCHAR(500),
dishCategory VARCHAR(20)
);
